# -*- coding: utf-8 -*-
from openerp import http

# class Vystavbacennik(http.Controller):
#      @http.route('/vystavba/vystavba/', auth='public')
#      def index(self, **kw):
#          return "Hello, world"
#      @http.route('/vystavba/vystavba/objects/', auth='public')
#      def list(self, **kw):
#          return http.request.render('vystavba.listing', {
#              'root': '/vystavba/vystavba',
#              'objects': http.request.env['vystavba.cennik'].search([]),
#          })
#      @http.route('/vystavba/vystavba/objects/<model("vystavba.vystavba"):obj>/', auth='public')
#      def object(self, obj, **kw):
#          return http.request.render('vystavba.object', {
#              'object': obj
#          })
