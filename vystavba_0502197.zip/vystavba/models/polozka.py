# -*- coding: utf-8 -*-

from openerp import models, fields, api

class VystavbaPolozka(models.Model):
    _name = 'vystavba.polozka'
    _description = "Vystavba - polozka cennika"
    _inherit = ['mail.thread', 'ir.needaction_mixin']

    name = fields.Char(required=True, string="Názov", size=100)
    description = fields.Text(string="Popis")
    kod = fields.Char(required=True, string="Kód", size=20)
    mj = fields.Selection([
        ('_', 'neurčená MJ'),
        ('kg', 'Kilogram'),
        ('ks', 'Kus'),
        ('km', 'Kilometer'),
        ('hod', 'Hodina'),
        ('m', 'Meter'),
        ('m2', 'Meter kubicky'),
        ('m3', 'Meter stvorcovy'),
        ('sada', 'sada'),
        ('vl.', 'vl'),
    ], string="Merná jednotka", default="_")
    is_balicek = fields.Boolean("Balíček", default=False)
    intern_id = fields.Char(string="Intern ID")
    intern_kod = fields.Char(string="Intern kód")
    active = fields.Boolean(default=True)
