# -*- coding: utf-8 -*-

from openerp import models, fields, api

class VystavbaCennik(models.Model):
    _name = 'vystavba.cennik'
    _description = "Vystavbovy cennik"
    _inherit = ['mail.thread', 'ir.needaction_mixin']

    name = fields.Char(required=True, string="Kód", size=30, help="Kód cenníka")
    description = fields.Text(string="Popis")  # popis
    platny_od = fields.Date(string="Platný od")
    platny_do = fields.Date(string="Platný do")
    dodavatel_id = fields.Many2one('res.partner', string='Dodávateľ', required=True)
    cennik_currency_id = fields.Many2one('res.currency', string="Mena", required=True)

    # osoba_id = fields.Many2One(comodel_name="vystavba.osoba", string="Osoba")
    # polozka_ids = fields.One2Many(comodel_name="vystavba.cennik.polozka", string="Polozky")
    # price_tax = fields.Monetary(compute='_compute_amount', string='Tax', store=True)

class VystavbaCennikPolozka(models.Model):
     _name = 'vystavba.cennik.polozka'
     _description = "Vystavbovy cennik - cena polozky cennika pre konkretneho partnera"

     cena = fields.Float(required=True, digits=(10, 2))
     cennik_id = fields.Many2one('vystavba.cennik', string="Cennik", required=True)
     # polozka_id = fields.Many2Many('vystavba.polozka', string="Polozka")
