# -*- coding: utf-8 -*-

from openerp import models, fields, api

class Osoba(models.Model):
     _name = 'res.partner'
     _inherit = "res.partner"

     icorc = fields.Char(string="ICO", size=30)
     cp_celkova_cena_limit = fields.Float(digits=(6,0), string="Celková cena cenovej ponuky", help="Za schvalenie objednavky pri prekroceni celkovej hodnoty je zodpovedna tato osoba.");
     # currency_id =