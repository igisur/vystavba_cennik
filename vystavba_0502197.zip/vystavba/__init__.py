# -*- coding: utf-8 -*-

# from . import controllers
from . import models


# TODO
# Polozka view, tree, import (mail thread ?)
# Cennik view, tree, import (mail thread ?)
# Objednavka view, tree, form (mail thread ?) , pridavanie poloziek, cena, prepocitanie total ceny
# user groups Dodavatel, PC, PM, Manager, Admin
# workflow
# Osoba - partner



# model
# partner inherits 'user'
#   : v ramci ODOO

# partner - access rights
# user_groups

# import/define polozka.kategorie

# import polozka

# import cennik

# import partner

# zobrazenie cennikov v kalendari / kanban
